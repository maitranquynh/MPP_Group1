package prob2A;

public class Main {

	public static void main(String[] args) {
		
		
		Student student = new Student("Eman");
		student.getGradReport().addGrad("A");
		System.out.println("Eman Grad is: " + student.getGradReport().getGrads());
		
		
		GradReport grads = student.getGradReport();
		System.out.println("Grads of : " + grads.getStudent());
		
	}

}
