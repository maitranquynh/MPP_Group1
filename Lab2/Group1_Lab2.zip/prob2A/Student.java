package prob2A;

public class Student {
	
	private String name;
	private GradReport grads;
	
	public Student (String name) {
		this.name = name;
		grads = new GradReport(this);
	}
	public String getName() {
		return name;
	}
	public GradReport getGradReport() {
		return grads;
	}
	@Override
	public String toString() {
		return name;
	}

}
