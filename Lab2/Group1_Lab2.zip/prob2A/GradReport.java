package prob2A;

import java.util.List;

public class GradReport {

	private String  grads; 
	private Student student;
	
	GradReport (Student student) {
		this.student = student;
	}
	
	public void addGrad(String grad) {
		grads = grad;
	}
	public String getGrads(){
	 
		return grads;
	}
	public Student getStudent() {
		return student;
	}
}
