package prob2b;

public class OrderLine {

	private int orderNumber;
	private Order order;
	
	public OrderLine(Order order, int orderNumber) {
		this.order = order;
		this.orderNumber = orderNumber;
	}
	
	public int getOrderNumber() {
		return orderNumber;
	}
	
	public Order getOrder() {
		return order;
	}
}
