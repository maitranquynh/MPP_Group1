package prob2b;

import java.util.ArrayList;

public class Order {
	private int id;
	private ArrayList<OrderLine> orderList;
	
	public Order(int id) {
		this.id = id;
		orderList = new ArrayList<>();
	}
	
	public void addOrder(int orderNumber) {
		OrderLine orderLine = new OrderLine(this, orderNumber);
		orderList.add(orderLine);
	}
	
	public ArrayList<OrderLine> getOrder() {
		return orderList;
	}

	public int getId() {
		return id;
	}
	@Override
	public String toString() {
		return orderList.toString();
	}

}
