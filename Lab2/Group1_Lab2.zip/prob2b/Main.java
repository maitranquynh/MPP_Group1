package prob2b;

public class Main {
	public static void main(String[] args) {
		
		Order order = new Order(1);
		order.addOrder(123);
		order.addOrder(321);
		
		System.out.println("first order Number is: " + order.getOrder().get(0).getOrderNumber());
		System.out.println("Secand order Number is: " + order.getOrder().get(1).getOrderNumber());
		
		OrderLine orderLine = order.getOrder().get(0);
		System.out.println("Order Id is: " + orderLine.getOrder().getId());
	}
}
