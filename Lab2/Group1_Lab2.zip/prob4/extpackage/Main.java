package lesson2.labs.prob4.extpackage;
import java.util.*;

import lesson2.labs.prob4.Student;
import lesson2.labs.prob4.Section;
import lesson2.labs.prob4.StudentSectionFactory;
import lesson2.labs.prob4.Transcript;


/** Shows how the design in this package of classes
 *  allows you to navigate in the way that the class
 *  diagram suggests
 */
public class Main {	
	
	public static void main(String[] args) { 
		Student bob = StudentSectionFactory.createStudent("1", "Bob");
		Student tim = StudentSectionFactory.createStudent("2", "Tim");
		Student allen = StudentSectionFactory.createStudent("3", "Allen");
		
		Section bio1 = StudentSectionFactory.createSection(1, "Biology 1");
		Section bio2 = StudentSectionFactory.createSection(2, "Biology 2");
		Section math = StudentSectionFactory.createSection(3, "Mathematics");
		
		StudentSectionFactory.newTranscriptEntry(bob, bio1, "A");
		StudentSectionFactory.newTranscriptEntry(bob, math, "B");
		StudentSectionFactory.newTranscriptEntry(tim, bio1, "B+");
		StudentSectionFactory.newTranscriptEntry(tim, math, "A-");
		StudentSectionFactory.newTranscriptEntry(allen, math, "B");
		StudentSectionFactory.newTranscriptEntry(allen, bio2, "B+");
		
		// The Transcript for any given Student
		System.out.println(getTranscript(bob));
		System.out.println(getTranscript(tim));
		System.out.println(getTranscript(allen));

		// List of letter grades for any given Section
		System.out.println("List of grades :");
		getGrades(bio1);
		getGrades(bio2);
		getGrades(math);
		
		// List of courses taken by any given Student
		System.out.println("List of courses :");
		getCourses(bob);
		getCourses(tim);
		getCourses(allen);

		//  List of all Students who got a particular grade (like a list of all "A" Students)
		System.out.println("List of all Students who got grade A :");
		for (Student s : StudentSectionFactory.getStudents("A")) {
			System.out.println(s.getName());
		}
	}
	
	private static Transcript getTranscript(Student s) {
		return s.getTranscript();
	}
	
	private static void getGrades(Section sec) {
		System.out.println("All grades for section " + sec.getCourseName() + " : " + sec.getGrades());
	}
	
	private static void getCourses(Student s) {
		System.out.println("All courses taken by  " + s.getName() + " : " + s.getCourses());
	}

}
