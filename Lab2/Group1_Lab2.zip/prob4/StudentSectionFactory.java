package lesson2.labs.prob4;
import java.util.*;

public class StudentSectionFactory {
	
	public static List<Student> student_list = new ArrayList<Student>();
	
	public static Section createSection(int secNum, String courseName) {
		if(courseName == null) 
			throw new IllegalArgumentException("Course name cannot be null");
		
		Section sec = new Section(secNum, courseName);
		
		return sec;
	}
	
	public static Student createStudent(String id, String name) {
		if(id == null || name == null) 
			throw new IllegalArgumentException("Student ID or name cannot be null");
		
		Student s = new Student(id, name);
		
		student_list.add(s);
		
		return s;
	}
	
	public static void newTranscriptEntry(Student s, Section sect, String grade) {
		TranscriptEntry te = new TranscriptEntry(s, sect, grade);
		
		s.getGrades().add(te);
		sect.getGradeSheet().add(te);
	}
	
	public static Set<Student> getStudents(String grade){
		Set<Student> result = new HashSet<>();
		
		for(Student s : student_list) {
			for(TranscriptEntry te : s.grades) {
				if(te.getGrade().equals(grade)) result.add(s);
			}
		}
		
		return result;
	}
	
}
