package lesson2.labs.prob4;

import java.util.*;

public class Section {
	String courseName;
	int sectionNumber;
	List<TranscriptEntry> gradeSheet;

	Section(int secNum, String courseName) {
		this.courseName = courseName;
		this.sectionNumber = secNum;
		gradeSheet = new ArrayList<TranscriptEntry>();
	}
	
	public String getCourseName() {
		return courseName;
	}
	
	public List<TranscriptEntry> getGradeSheet() {
		return gradeSheet;
	}

	public void setGradeSheet(List<TranscriptEntry> gradeSheet) {
		this.gradeSheet = gradeSheet;
	}

	public ArrayList<String> getGrades() {
		ArrayList<String> grades = new ArrayList<String>();
		
		for(TranscriptEntry te : this.gradeSheet) {
			grades.add(te.getGrade());
		}
		
		return grades;
	}
	
}
