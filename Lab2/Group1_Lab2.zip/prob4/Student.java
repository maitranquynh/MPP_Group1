package lesson2.labs.prob4;

import java.util.*;

public class Student {
	String id;
	String name;
	List<TranscriptEntry> grades;
	
	public List<TranscriptEntry> getGrades() {
		return grades;
	}

	public void setGrades(List<TranscriptEntry> grades) {
		this.grades = grades;
	}

	public Transcript getTranscript() {
		return new Transcript(grades, this);	
	}
	
	public String getName() {
		return name;
	}
	
	Student(String id, String name) {
		this.id = id;
		this.name = name;
		grades = new ArrayList<>();
	}
	
	public ArrayList<String> getCourses() {
		ArrayList<String> grades = new ArrayList<String>();
		
		for(TranscriptEntry te : this.grades) {
			grades.add(te.getSection().getCourseName());
		}
		
		return grades;
	}
	
}
