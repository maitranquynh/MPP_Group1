package lab3.prob4;

public class Trailer extends Property{
	@Override
	public double computeRent() {
		return 500.0;
	}

}
