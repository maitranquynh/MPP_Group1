package lab3.prob4;

public class Condo extends Property{
    private int floorNum;
    
	public Condo(int floorNum) {
		this.floorNum = floorNum;
	}

	@Override
	public double computeRent() {
		return 400 * this.floorNum;
	}

}
