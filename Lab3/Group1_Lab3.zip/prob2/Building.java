package lesson3.labs.prob2;
import java.util.*;

class Building {
	String name;
	double maintenance_cost;
	ArrayList<Apartment> lApartment;
	
	Building(String name, double maintenance_cost){
		this.name = name;
		this.maintenance_cost = maintenance_cost;
		lApartment = new ArrayList<Apartment>();
	}
	
	void addAppartment(String name, double rent) {
		this.lApartment.add(new Apartment(name, rent));
	}
	
	double getTotalRent() {
		double res = 0;
		for(Apartment a : lApartment) {
			res += a.getRent();
		}
		
		return (res - maintenance_cost);
	}
}
