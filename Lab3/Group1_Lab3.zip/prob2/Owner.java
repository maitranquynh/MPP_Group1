package lesson3.labs.prob2;
import java.util.*;

class Owner {
	String name;
	ArrayList<Building> lBuilding;
	
	Owner(String name){
		this.name = name;
		lBuilding = new ArrayList<Building>();
	}
	
	ArrayList<Building> getBuildingList() {
		return this.lBuilding;
	}
	
	void addBuilding(String name, double maintenance_cost) {
		lBuilding.add(new Building(name, maintenance_cost));
	}
	
	double getIncome() {
		double res = 0;
		for (Building b : lBuilding) {
			res += b.getTotalRent();
		}
		
		return res;
	}
	
	public static void main(String[] args) {
		Owner o = new Owner("Hoa");
		
		o.addBuilding("Utopia Park", 100);
		for (Building b : o.getBuildingList()) {
			b.addAppartment("U001", 50);
			b.addAppartment("U002", 60);
			b.addAppartment("U003", 70);
		}
		
		System.out.println("Total income of Hoa: " + o.getIncome());
	}	
}

