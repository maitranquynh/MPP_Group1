package lesson3.labs.prob2;

class Apartment {
	String name;
	double rent;
	
	Apartment(String name, double rent){
		this.name = name;
		this.rent = rent;
	}
	
	double getRent() {
		return this.rent;
	}
}
