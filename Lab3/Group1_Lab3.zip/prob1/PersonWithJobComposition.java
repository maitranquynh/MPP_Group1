package lesson3.labs.prob1;

public final class PersonWithJobComposition {
	
	private Person per;
	private double salary;
	
	public Person getPerson() {
		return this.per;
	}
	
	public double getSalary() {
		return salary;
	}
	PersonWithJobComposition(String n, double s) {
		per = new Person(n);
		salary = s;
	}
	
	@Override
	public boolean equals(Object aPerson) {
		if(aPerson == null) return false; 
		if(!(aPerson instanceof PersonWithJobComposition)) return false;
		PersonWithJobComposition p = (PersonWithJobComposition)aPerson;
		boolean isEqual = this.getPerson().equals(p.getPerson()) &&
				this.getSalary()==p.getSalary();
		return isEqual;
	}
	public static void main(String[] args) {
		PersonWithJobComposition p1 = new PersonWithJobComposition("Joe", 30000);
		Person p2 = new Person("Joe");
		//As PersonsWithJobs, p1 should be equal to p2
		System.out.println("p1.equals(p2)? " + p1.equals(p2)); 
		System.out.println("p2.equals(p1)? " + p2.equals(p1));
	}


}
